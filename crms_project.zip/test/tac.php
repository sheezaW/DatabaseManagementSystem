<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Terms & Conditions</title>
	 <style>
  *{
      margin: 0;
      padding: 0;
  }
    body{
      background-image: url(images/bg.jpg);
      background-size: auto;
      background-position: center;
      font-family: sans-serif;
    }
    .form-box{
      width: 500px;
      background: rgba(0, 0, 0, 0.8);
      margin: 8% auto;
      padding:  50px 0;
      color: #fff;
      box-shadow: 0 0 20px 2px;
    }
    h1{
      	text-align: center;
     	margin-top: 50px;
    }
    h2{
      	text-align: center;
     	margin-bottom: 40px;
    }
    h5{
    	color: red;
      	margin-bottom: 40px;
    }
    .points{
    	 padding-left: 40px;
    	 padding-right: 40px;
    	 padding-bottom: 15px;
    }
 </style>
</head>
<body>

	<h1>CRIME REPORT MANAGEMENT SYSTEM</h1>
		<div class="form-box">
			<div class="points">
			<h2>TERMS AND CONDITIONS OF USE</h2>  
			<h5>PLEASE READ THESE TERMS OF USE CAREFULLY BEFORE PROCEEDING TO USING CRMS</h5> 
			<p> By using CRMS, you signify your assent to these terms of use and agree to comply with all applicable laws and regulations</p>
		</div>
		<div class="points">
	<ul>
			<div class="points">
	<li>You are advised to not share your credentials with anyone.</li>
</div>
	<div class="points">
	<li>CRMS reserves the right to revoke your access at anytime.</li>
</div>
	<div class="points">
    <li>You can only make legitimate reports and you will be fully held accountable for any misinformation provided.</li>
</div>
	</ul>
</div>
		</div>
</body>
</html>