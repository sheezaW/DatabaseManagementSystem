<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Page Title</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

   <style>
  *{
      margin: 0;
      padding: 0;
  }
    body{
      background-image: url(images/bg.jpg);
      background-size: auto;
      background-position: center;
      font-family: sans-serif;
    }
    .form-box{
      width: 500px;
      background: rgba(0, 0, 0, 0.8);
      margin: 12% auto;
      padding:  50px 0;
      color: #fff;
      box-shadow: 0 0 20px 2px;
    }
    h1{
        text-align: center;
      margin-top: 40px;
    }
.b1{
  text-align: center;
  padding-top: 10px;
  padding-bottom: 5px;
}
.btn{ 
    display: block;
    width: 115px;
    height: 25px;
    background: red;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-weight: bold;
    line-height: 25px;
    text-decoration: none;

}
 </style>
  </head>

  <body>
    <div class="form-box">
      <h1>Record Added Successfully!</h1>
     
      <div class="b1">
          <button onclick="window.location.href=crimeform.php;">
          <a href="crimeform.php" class="btn">Add Record</a>
      </div>
      <div class="b1">
          <button onclick="window.location.href=index.php;">
          <a href="index.php" class="btn">Home</a>
      </div>
    </div>
  </body>
</html>