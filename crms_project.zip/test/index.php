<!DOCTYPE html>
<html>
<head>
  <title>CRMS Home Page</title>
  <style>
  *{
      margin: 0;
      padding: 0;
  }
    body{
      background-image: url(images/bg.jpg);
      background-size: auto;
      background-position: center;
      font-family: sans-serif;
    }
    .form-box{
      width: 500px;
      background: rgba(0, 0, 0, 0.8);
      margin: 12% auto;
      padding:  50px 0;
      color: #fff;
      box-shadow: 0 0 20px 2px;
    }
    h1{
      text-align: center;
      margin-bottom: 40px;
    }
.b1{
  text-align: center;
  padding-top: 10px;
  padding-bottom: 5px;
}
.btn{ 
    display: block;
    width: 115px;
    height: 25px;
    background: red;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-weight: bold;
    line-height: 25px;
    text-decoration: none;

}

 </style>


</head>
  <body>
    <div class="form-box">
          <h1>CRMS Home Page</h1>

      <div class="b1">    
          <button onclick="window.location.href=signin.php;">
          <a href="signin.php" class="btn">Sign In</a>
        </div>

      <div class="b1">
          <button onclick="window.location.href=signup.php;">
          <a href="signup.php" class="btn">Sign Up</a>
      </div>
    </div>    
  </body>
</html>