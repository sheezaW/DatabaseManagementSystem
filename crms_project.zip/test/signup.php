<?php
    function test_input($data) 
    {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "crms";
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    $check = true;
    $fname_err = $lname_err = $eid_err = $phone_err = $email_err = $pass_err = $con_pass_err = "";
    if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        if (empty($_POST["fname"])) {
                $check = false;
                $fname_err = "First Name is required!";
            }else {
            if (!preg_match("/^[a-zA-Z\. ]*$/", $_POST["fname"])) 
            {
                $check = false;
                $fname_err = "Only letters and white space allowed"; 
            }
          }

        if(empty($_POST["lname"])){
            $check = false;
            $lname_err = "Last name is required!";
        }else {
            if (!preg_match("/^[a-zA-Z\. ]*$/", $_POST["lname"])) 
            {
                $check = false;
                $lname_err = "Only letters and white space allowed"; 
            }
        }
        
        if(empty($_POST["employeeid"])){
            $check = false;
            $eid_err = "Employee ID is required!";
        }else {
            if (!preg_match("/^[0-9]{5}$/",$_POST["employeeid"])) {
                $check = false;
                $eid_err = "INVALID ID, Only 5 digit ID is allowed";
            }
        }
        
        if(empty($_POST["phone"])){
            $check = false;
            $phone_err = "Phone number is required!";
        }else {
            if (!preg_match("/^[0-9]{4}-[0-9]{4}-[0-9]{3}$/",$_POST["phone"])) {
                $check = false;
                $phone_err = "INVALID phone number";
            }
        }    
        
        if(empty($_POST["email"])){
            $check = false;
            $email_err = "E-mail is required!";
        }else {
            if (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
                $check = false;
                $email_err = "INVALID E-mail";
            }
        }  
        
        if(empty($_POST["password"])) {
            $check = false;
            $pass_err = "Password is required!";
        }
        elseif ($_POST["password"] != $_POST["psw-confirm"]) {
                $check = false;
                $con_pass_err = "Passwords do not match!";
        }
        else{
            if(strlen($_POST["password"]) <5) {
                $check = false;
                $pass_err = "Password is INVALID";
            }
        }  
        if($check)
        {
            $fname=test_input($_POST["fname"]);
            $lname=test_input($_POST['lname']);
            $eid=test_input($_POST['employeeid']);
            $phone=test_input($_POST['phone']);
            $email=test_input($_POST['email']);
            $pass=test_input($_POST['password']);
            $con_pass=test_input($_POST['psw-confirm']);  

            $count=$conn->query("SELECT COUNT(*) FROM `signup` WHERE `employee-id` = ".$eid);  
            $rows = mysqli_fetch_array($count);
            $total = $rows[0];
            if($total==0)  
            {  
                $sql="INSERT INTO `signup`(`first name`, `last name`, `phone`, `password`, `employee-id`) VALUES('$fname', '$lname', '$phone', '$pass', '$eid')";  
              
                $conn->query($sql);  
            }
        }
    }  
    $conn->close();
?> 

<!DOCTYPE HTML>
<html>
    <head>
    <style>
      *{
          margin: 0;
          padding: 0;
      }
        body{
          background-image: url(images/bg.jpg);
          background-size: auto;
          background-position: center;
          font-family: sans-serif;
        }
        .form-box{
          width: 500px;
          background: rgba(0, 0, 0, 0.8);
          margin: 8% auto;
          padding:  50px 0;
          color: #fff;
          box-shadow: 0 0 20px 2px;
        }
        h1{
          text-align: center;
          margin-bottom: 40px;
        }
    .register{
        padding-left: 40px;
        padding-bottom: 15px;
    }
    .registerbutton{
        text-align: center;
        margin-top: 10px;
        padding-top: 10px; 
    }
    .container1 h1{
        margin-top: 40px;
    }
    #notice{
        color:  red;
    }
    input[type=text], select {
  width: 50%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=password], select {
  width: 50%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 50%;
  background-color: red;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

     </style>
    </head>
    <body>
        <div class="container1"> <!-- container for form starts here -->    
            <header id="main-header"> <!-- Main Heading -->
              <h1> Crime Report Management System </h1>
            </header>  
        </div>

            <form name = "signup" action="" method="POST">
                <div class="form-box">
              
                <h1>Sign Up</h1>

                <div class="register">
                   
                    <p id="notice">Please fill in this form to create an account.</p>
                </div>

                <div class="register">
                    <label for="fname">First Name:</label>
                </div>
                <div class="register">
                    <input type="text" placeholder="First Name" name="fname"> 
                    <span class="error">* <?php echo $fname_err;?></span>
                </div>

                <div class="register">   
                    <label for="lname">Last Name:</label>
                                    </div>
                <div class="register">
                    <input type="text" placeholder="Last Name" name="lname">
                    <span class="error">* <?php echo $lname_err;?></span>
                </div>

                <div class="register">
                    <label for="empleeid">Employee ID:</label>
                                    </div>
                <div class="register"><input type="text" name="employeeid" placeholder="XXXXX">
                    <span class="error">* <?php echo $eid_err;?></span>
                </div>

                <div class="register">
                      <label for="phone">Phone Number:</label>
                                    </div>
                <div class="register"><input type="text" name="phone" placeholder="03XX-XXXX-XXX">
                    <span class="error">* <?php echo $phone_err;?></span>
                </div>

                <div class="register">
                     <label for="email">Email:</label>
                                    </div>
                <div class="register"><input type="text" placeholder="Enter Email" name="email" >
                    <span class="error">* <?php echo $email_err;?></span>
                </div>

                <div class="register">
                    <label for="psw">Password:</label>
                                    </div>
                <div class="register"><input type="password" placeholder="Enter Password" name="password" >
                    <span class="error">* <?php echo $pass_err;?></span>
                </div>

                <div class="register">
                    <label for="psw-confirm">Confirm Password:</label>
                                    </div>
                <div class="register"><input type="password" placeholder="Confirm Password" name="psw-confirm" >
                    <span class="error">* <?php echo $con_pass_err;?></span>
                </div>

                <br>
                <hr> 
                <br>

                <div class="register">
                <p>By creating an account you agree to our <a href="tac.html">Terms & Conditions</a>.</p>
                </div>

                <div class="registerbutton">
                    <input type="submit" value="Register" name="submit" />  
                </div>

            </div> <!-- form  ends -->
        </form>
    </body>
</html>