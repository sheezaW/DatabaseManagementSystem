<?php
    function test_input($data) 
    {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "crms";
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    $check = true;
    $eid_err  = $pass_err = "";
    if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        
        if(empty($_POST["employeeid"])){
            $check = false;
            $eid_err = "Employee ID is required!";
        }else {
            if (!preg_match("/^[0-9]{5}$/",$_POST["employeeid"])) {
                $check = false;
                $eid_err = "INVALID ID, Only 5 digit ID is allowed";
            }
        }
        
        if(empty($_POST["password"])) {
            $check = false;
            $pass_err = "Password is required!";
        }
        else{
            if(strlen($_POST["password"]) <5) {
                $check = false;
                $pass_err = "Password is INVALID";
            }
        }  
        if($check)
        {
            $eid=test_input($_POST['employeeid']);
            $pass=test_input($_POST['password']); 

            $sql="SELECT `first name` as fn, `password` as ps FROM `signup` WHERE `employee-id` = ".$eid;  
            $result = $conn->query($sql);
            $row = $result->fetch_assoc();
            if($result->num_rows > 0)  
            {   
                if($pass == $row["ps"]) {
                echo "Welcome ". $row["fn"];
                }
                else{
                    $pass_err = "Incorrect ID or password, please try again";
                    
                }
            }
        }
    }  
    $conn->close();
?> 
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title> Crime Report Management System </title>
 <style>
  *{
      margin: 0;
      padding: 0;
  }
    body{
      background-image: url(images/bg.jpg);
      background-size: auto;
      background-position: center;
      font-family: sans-serif;
    }
    .form-box{
      width: 500px;
      background: rgba(0, 0, 0, 0.8);
      margin: 12% auto;
      padding:  50px 0;
      color: #fff;
      box-shadow: 0 0 20px 2px;
    }
    h1{
      text-align: center;
      margin-bottom: 40px;
    }
.b1{
  text-align: center;
  padding-top: 10px;
  padding-bottom: 5px;
}
.login{
    padding-left: 40px;
    padding-bottom: 15px;
}
.loginbutton{
    text-align: center;
    margin-top: 15px;
    padding-top: 10px; 
}
.container h1{
    margin-top: 40px;
}
input[type=text], select {
  width: 50%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=password], select {
  width: 50%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 50%;
  background-color: red;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

 </style>
    </head>
     <body> <!-- main body -->
     
        <div class="container"> <!-- container for form starts here -->
            
            <header id="main-header"> <!-- Main Heading -->
              <h1> Crime Report Management System </h1>
            </header>

        </div>
        
        <form name="signin" action="" method="POST">
           <div>
            <div class="form-box">
                
                    <h1>Sign In</h1>
                    <div class="login">
                    Employee ID:
                    </div>
                    <div class="login">
                    <input type="text" placeholder="Enter ID" name="employeeid">
                    <span class="error">* <?php echo $eid_err; ?> </span>
                    </div>

                    <div class="login">
                    Password:
                    </div>
                    <div class="login">
                    <input type="password" placeholder="Enter Password" name="password">  
                    <span class="error">* <?php echo $pass_err; ?> </span>
                    </div>
                
                    <div class="loginbutton">
                        <input type="submit" value = "Sign In" />
                    </div>
            </div>
        </form> 
      </div>
    </body>
</html>