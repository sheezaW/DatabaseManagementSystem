<?php
  function test_input($data) 
  {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }

  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "crms";
  $conn = new mysqli($servername, $username, $password, $dbname);
  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  $check = true;
  $name_err = $cnic_err =  $phone_err =  "";
  if ($_SERVER["REQUEST_METHOD"] == "POST")
  {
    if (empty($_POST["name"])) {
      $check = false;
      $name_err = "Victim Name is required!";
      }else {
      if (!preg_match("/^[a-zA-Z\. ]*$/", $_POST["name"])) 
      {
          $check = false;
          $name_err = "Only letters and white space allowed"; 
      }
    }
    
    if(empty($_POST["cnic"])){
        $check = false;
        $eid_err = "CNIC is required!";
    }else {
        if (!preg_match("/^[0-9]{13}$/",$_POST["cnic"])) {
            $check = false;
            $eid_err = "INVALID CNIC, Only 13 digits are allowed";
        }
    }
    
    if(empty($_POST["phone"])){
        $check = false;
        $phone_err = "Phone number is required!";
    }else {
        if (!preg_match("/^[0-9]{4}-[0-9]{4}-[0-9]{3}$/",$_POST["phone"])) {
            $check = false;
            $phone_err = "INVALID phone number";
        }
    }    
    
    if($check)
    {
      $name=test_input($_POST["name"]);
      $cnic=test_input($_POST['cnic']);
      $phone=test_input($_POST['phone']);
      $district=test_input($_POST['districts']);
      $city=test_input($_POST['city']); //division
      $address=test_input($_POST['address']); //crime location
      $crime=test_input($_POST['crime']);
      $date=test_input($_POST['date']);
      $death=test_input($_POST['death']);

      //put data in the reporter table --checked
      $conn->query("INSERT INTO `reporter`(`CNIC`, `Name`, `Phone`) VALUES('$cnic','$name', '$phone')");
    
      //grab district ID from table by passing the district name --checked
      $sql_d_id=mysqli_query($conn,"SELECT `ID` FROM `district` WHERE `Name` = '$district'");
      $d_id=mysqli_fetch_array($sql_d_id);
      
      //grab crime ID from table by passing the crime type --checked
      $sql_c_id=mysqli_query($conn,"SELECT `ID` FROM `crime` WHERE `Name` = '$crime'");
      $c_id=mysqli_fetch_array($sql_c_id);
    
      $conn->query("INSERT INTO `form`(`FIR`, `District_ID`, `Crime_ID`, `c_location`, `date_time`, `death`) VALUES ('','$d_id[0]','$c_id[0]','$address','$date','$death')");
    }
  }
    $conn->close();
?>
<!DOCTYPE html>
<html>
  <head>
    <title> Crime Report Management System </title>
    <style>
      *{
        margin: 0;
        padding: 0;
      }
      body{
        background-image: url(images/bg.jpg);
        background-size: auto;
        background-position: center;
        font-family: sans-serif;
      }
      .form-box{
        width: 500px;
        background: rgba(0, 0, 0, 0.8);
        margin: 6% auto;
        padding:  50px 0;
        color: #fff;
        box-shadow: 0 0 20px 2px;
      }
      h1{
        text-align: center;
        margin-bottom: 40px;
      }
      .form-group{
          padding-left: 40px;
          padding-bottom: 15px;
      }
      .form-group1{
          padding-left: 40px;
          padding-bottom: 15px;
      }
      .button{
          text-align: center;
          margin-top: 10px;
          padding-top: 10px; 
      }
      .container3 h1{
          margin-top: 40px;
      }
      #main-footer{
        text-align: center;
        color: white;
        font-size: 12px;
      }
      #thing{
        color: red;
      }
      input[type=text], select {
  width: 50%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=password], select {
  width: 50%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 50%;
  background-color: red;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

    </style>
  </head>
  <body> <!-- main body -->
    <div class="container3"> <!-- container for form starts here -->
      <header id="main-header">
        <h1> Crime Report Management System </h1>
      </header>
    </div>
    
    <form class="my-form" method="post" action="" id="formwrap">
      
      <div class="form-box">  <!-- this is where the form starts -->
        <h1>Crime Report Form</h1>
        
        <div class="form-group">
          <p id="thing">Please fill in the form correctly to provide the information regarding the crime.</p>
        </div>
        
        <div class="form-group">
          <label for="name">Name of Victim:</label>
        </div>
        <div class="form-group">
          <input type="text" id="name" name="name" placeholder="Name" >
          <span class="error">* <?php echo $name_err;?></span>
        </div>
        
        <div class="form-group">
          <label for="cnic">CNIC:</label>
        </div>
        <div class="form-group">
          <input type="text" id="cnic" name="cnic" placeholder="35XXXXXXXXXXX" >
          <span class="error">* <?php echo $cnic_err;?></span>
        </div>
        
        <div class="form-group">
          <label for="phone">Phone Number:</label>
        </div>  
        <div class="form-group">  
          <input type="text" id="phone" name="phone" placeholder="03XX-XXXX-XXX" >
          <span class="error">* <?php echo $phone_err;?></span>
        </div>

        <div class="form-group">
          <label for="districts">District:</label>
          </div>
          <div class="form-group">
        <select name="districts" id="districts" required>
            <option value="" disabled selected>Select District</option>
            <option value="Arifwala">Arifwala</option>
            <option value="Attock">Attock</option>
            <option value="Bahawalnagar">Bahawalnagar</option>
            <option value="Bahawalpur">Bahawalpur</option>
            <option value="Bhakkar">Bhakkar</option>
            <option value="Chakwal">Chakwal</option>
            <option value="Chiniot">Chiniot</option>
            <option value="D.G.Khan">D.G.Khan</option>
            <option value="Faisalabad">Faisalabad</option>
            <option value="Gujranwala">Gujranwala</option>
            <option value="Hafizabad">Hafizabad</option>
            <option value="Jhang">Jhang</option>
            <option value="Jhelum">Jhelum</option>
            <option value="Khanewal">Khanewal</option>
            <option value="Khushab">Khushab</option>
            <option value="Lahore">Lahore</option>
            <option value="Layyah">Layyah</option>
            <option value="Lodhran">Lodhran</option>
            <option value="Mandi Baha-ud-Din">Mandi Baha-ud-Din</option>
            <option value="Mianwali">Mianwali</option>
            <option value="Multan">Multan</option>
            <option value="Muzaffargarh">Muzaffargarh</option>
            <option value="Nankana Sahib">Nankana Sahib</option>
            <option value="Narowal">Narowal</option>
            <option value="Okara">Okara</option>
            <option value="Pakpattan">Pakpattan</option>
            <option value="R.Y.Khan">R.Y.Khan</option>
            <option value="Rajanpur">Rajanpur</option>
            <option value="Rawalpindi">Rawalpindi</option>
            <option value="Sargodha">Sargodha</option>
            <option value="Sheikhupura">Sheikhupura</option>
            <option value="Sialkot">Sialkot</option>
            <option value="T.T.Singh">T.T.Singh</option>
            <option value="Vehari">Vehari</option>
          </select>
        </div>

        <div class="form-group">
        
          <label for="city" >City:</label>
        </div>
        <div class="form-group">
        
          <select name="city" id="city" required>
            <option value="" disabled selected>Select City</option>
            <optgroup label="Highly-Populated">
              <option value="lahore">Lahore</option>
              <option value="faislabad">Faislabad</option>
              <option value="rawalpindi">Rawalpindi</option>
              <option value="gujaranwala">Gujaranwala</option>
              <option value="multan">Multan</option>
              <option value="bahalwalpur">Bahawalpur</option>
              <option value="sargodha">Sargodha</option>
              <option value="sialkot">Sialkot</option>
            </optgroup>
            <optgroup label="Low-Populated">         
              <option value="deraghazikhan">Dera Ghazi Khan</option>
              <option value="gujrat">Gujrat</option>
              <option value="sahiwal">Sahiwal</option>
            </optgroup>
          </select>
        </div>
    
        <div class="form-group">
         <label>Address:</label>
        </div>
         <div class="form-group">
         <input type="text" name="address" placeholder="Enter Address here" required></textarea>
        </div>

        <div class="form-group">
          <label for="crime" >Crime:</label>
          </div>
          <div class="form-group">
        <select name="crime" id="crime" required>
            <option value="" disabled selected>Select the Crime</option>
            <optgroup label="Major Crime">
              <option value="murder">Murder</option>
              <option value="rape">Rape</option>
              <option value="attempted murder">Attempted Murder</option>
              <option value="kidnapping/abduction">Kidnapping / Abduction</option>
              <option value="burglary">Burglary</option>
              <option value="dacoity">Dacoity</option>
            </optgroup>
            <optgroup label="Minor Crime">
              <option value="robbery">Robbery</option>
              <option value="assault">Assault</option>
              <option value="rioting">Rioting</option>
              <option value="cattle theft">Cattle Theft</option>
              <option value="vehicle theft">Vehicle Theft</option>
              <option value="other theft">Other Theft</option>
              <option value="others">Others</option>
            </optgroup>
          </select>
        </div>
        
        <div class="form-group">
            <label for="date">Date and Time:</label>
          </div>
            <div class="form-group">
            <input type="datetime-local" name="date" id="date" required>
          </div>
    
        <div class="form-group1">
          <div class="question">
            <label >Death:</label>
               <div class="question-answer">
                <input type="radio" value="none" id="radio_1" name="death"required/>
                <label for="radio_1" class="radio"><span>Yes</span></label>
                <input type="radio" value="none" id="radio_2" name="death"/>
                <label for="radio_2" class="radio"><span>No</span></label>
              </div>
          </div> 
        </div>
   
        <div class="button"><!-- questions here -->
          <input id="submitButton" class="block" type="submit" value="Submit Form"/>
             
              </div> <!-- class button ends here --> 
      </form>
 
  </div> 

  </div> <!-- Container ends here -->

    <footer id="main-footer">
        <p>Copyright &copy; 2021, CRMS (BS-AI)</p>
    </footer>

  </body> <!-- main body -->
</html>