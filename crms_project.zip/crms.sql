-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 18, 2021 at 09:01 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crms`
--

-- --------------------------------------------------------

--
-- Table structure for table `code to id`
--

CREATE TABLE `code to id` (
  `id` int(4) NOT NULL,
  `Code` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `code to id`
--

INSERT INTO `code to id` (`id`, `Code`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 2),
(5, 2),
(6, 2),
(7, 2),
(8, 3),
(9, 3),
(10, 3),
(11, 3),
(12, 4),
(13, 4),
(14, 4),
(15, 4),
(16, 4),
(17, 5),
(18, 5),
(19, 5),
(20, 6),
(21, 6),
(22, 6),
(23, 6),
(24, 7),
(25, 7),
(26, 7),
(27, 7),
(28, 8),
(29, 8),
(30, 8),
(31, 8),
(32, 9),
(33, 9),
(34, 9),
(35, 9);

-- --------------------------------------------------------

--
-- Table structure for table `counter`
--

CREATE TABLE `counter` (
  `district_id` int(4) NOT NULL,
  `crime_id` int(4) NOT NULL,
  `count` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `counter`
--

INSERT INTO `counter` (`district_id`, `crime_id`, `count`) VALUES
(2, 7, 739),
(2, 12, 105),
(2, 1, 94),
(2, 2, 140),
(2, 3, 394),
(2, 5, 17),
(2, 6, 152),
(2, 4, 283),
(2, 9, 334),
(2, 8, 167),
(2, 10, 410),
(2, 11, 3979),
(1, 7, 623),
(1, 12, 136),
(1, 1, 109),
(1, 2, 147),
(1, 3, 294),
(1, 5, 35),
(1, 6, 206),
(1, 4, 224),
(1, 9, 137),
(1, 8, 291),
(1, 10, 576),
(1, 11, 6288),
(3, 7, 777),
(3, 12, 136),
(3, 1, 138),
(3, 12, 136),
(3, 2, 154),
(3, 3, 622),
(3, 5, 36),
(3, 6, 131),
(3, 4, 399),
(3, 9, 362),
(3, 8, 315),
(3, 10, 996),
(3, 11, 6735),
(4, 7, 310),
(4, 1, 86),
(4, 12, 111),
(4, 2, 79),
(4, 3, 247),
(4, 5, 14),
(4, 6, 200),
(4, 4, 152),
(4, 9, 383),
(4, 8, 199),
(4, 10, 329),
(4, 11, 4683),
(5, 7, 207),
(5, 1, 38),
(5, 12, 41),
(5, 2, 41),
(5, 3, 129),
(5, 5, 3),
(5, 6, 29),
(5, 4, 64),
(5, 9, 47),
(5, 8, 71),
(5, 10, 248),
(5, 11, 1918),
(6, 7, 694),
(6, 1, 127),
(6, 12, 106),
(6, 2, 133),
(6, 3, 387),
(6, 5, 19),
(6, 6, 76),
(6, 4, 217),
(6, 9, 201),
(6, 8, 248),
(6, 10, 692),
(6, 11, 5331),
(7, 7, 369),
(7, 1, 107),
(7, 12, 104),
(7, 2, 56),
(7, 3, 175),
(7, 5, 2),
(7, 6, 30),
(7, 4, 157),
(7, 9, 113),
(7, 8, 140),
(7, 10, 356),
(7, 11, 2659),
(9, 7, 986),
(9, 1, 384),
(9, 12, 361),
(9, 2, 202),
(9, 3, 761),
(9, 5, 144),
(9, 6, 2005),
(9, 4, 598),
(9, 9, 1323),
(9, 8, 459),
(9, 10, 1686),
(9, 11, 20728),
(8, 7, 356),
(8, 1, 75),
(8, 12, 40),
(8, 2, 39),
(8, 3, 159),
(8, 5, 42),
(8, 6, 118),
(8, 4, 222),
(8, 9, 91),
(8, 8, 91),
(8, 10, 233),
(8, 11, 3147),
(10, 7, 664),
(10, 1, 89),
(10, 12, 69),
(10, 2, 90),
(10, 3, 153),
(10, 5, 35),
(10, 6, 144),
(10, 4, 187),
(10, 9, 142),
(10, 8, 131),
(10, 10, 390),
(10, 11, 3420),
(11, 7, 404),
(11, 1, 109),
(11, 12, 84),
(11, 2, 60),
(11, 3, 188),
(11, 5, 28),
(11, 6, 255),
(11, 4, 186),
(11, 9, 226),
(11, 8, 117),
(11, 10, 270),
(11, 11, 3327),
(12, 7, 817),
(12, 1, 193),
(12, 12, 295),
(12, 2, 89),
(12, 3, 464),
(12, 5, 45),
(12, 6, 1444),
(12, 4, 380),
(12, 9, 1014),
(12, 8, 177),
(12, 10, 928),
(12, 11, 13786),
(13, 7, 472),
(13, 1, 74),
(13, 12, 74),
(13, 2, 41),
(13, 3, 161),
(13, 5, 21),
(13, 6, 159),
(13, 4, 91),
(13, 9, 52),
(13, 8, 99),
(13, 10, 150),
(13, 11, 3548),
(14, 7, 324),
(14, 1, 65),
(14, 12, 111),
(14, 2, 34),
(14, 3, 293),
(14, 5, 32),
(14, 6, 161),
(14, 4, 155),
(14, 9, 122),
(14, 8, 132),
(14, 10, 253),
(14, 11, 3476),
(15, 7, 384),
(15, 1, 46),
(15, 12, 72),
(15, 2, 18),
(15, 3, 103),
(15, 5, 11),
(15, 6, 138),
(15, 4, 46),
(15, 9, 67),
(15, 8, 79),
(15, 10, 167),
(15, 11, 2712),
(16, 7, 771),
(16, 1, 125),
(16, 12, 190),
(16, 2, 62),
(16, 3, 341),
(16, 5, 33),
(16, 6, 871),
(16, 4, 369),
(16, 9, 643),
(16, 8, 181),
(16, 10, 669),
(16, 11, 10160),
(17, 7, 1345),
(17, 1, 445),
(17, 12, 622),
(17, 2, 144),
(17, 3, 2810),
(17, 5, 101),
(17, 6, 4445),
(17, 4, 4619),
(17, 9, 6320),
(17, 8, 216),
(17, 10, 8998),
(17, 11, 56803),
(19, 7, 663),
(19, 1, 229),
(19, 12, 345),
(19, 2, 100),
(19, 3, 550),
(19, 5, 91),
(19, 6, 829),
(19, 4, 463),
(19, 9, 425),
(19, 8, 164),
(19, 10, 913),
(19, 11, 7520),
(18, 7, 435),
(18, 1, 86),
(18, 12, 81),
(18, 2, 58),
(18, 3, 194),
(18, 5, 50),
(18, 6, 206),
(18, 4, 91),
(18, 9, 67),
(18, 8, 166),
(18, 10, 258),
(18, 11, 3753),
(22, 7, 1276),
(22, 1, 138),
(22, 12, 156),
(22, 2, 135),
(22, 3, 631),
(22, 5, 76),
(22, 6, 1020),
(22, 4, 714),
(22, 9, 1647),
(22, 8, 285),
(22, 10, 1591),
(22, 11, 10380),
(20, 7, 660),
(20, 1, 99),
(20, 12, 125),
(20, 2, 116),
(20, 3, 299),
(20, 5, 35),
(20, 6, 255),
(20, 4, 107),
(20, 9, 158),
(20, 8, 137),
(20, 10, 501),
(20, 11, 4510),
(21, 7, 471),
(21, 1, 56),
(21, 12, 52),
(21, 2, 63),
(21, 3, 250),
(21, 5, 17),
(21, 6, 107),
(21, 4, 93),
(21, 9, 120),
(21, 8, 152),
(21, 10, 375),
(21, 11, 3446),
(23, 7, 770),
(23, 1, 95),
(23, 12, 132),
(23, 2, 97),
(23, 3, 418),
(23, 5, 53),
(23, 6, 270),
(23, 4, 292),
(23, 9, 268),
(23, 8, 329),
(23, 10, 657),
(23, 11, 7593),
(27, 7, 1067),
(27, 1, 268),
(27, 12, 325),
(27, 2, 38),
(27, 3, 467),
(27, 5, 50),
(27, 6, 606),
(27, 4, 534),
(27, 9, 1570),
(27, 8, 54),
(27, 10, 582),
(27, 11, 11044),
(24, 7, 327),
(24, 1, 94),
(24, 12, 81),
(24, 2, 14),
(24, 3, 64),
(24, 5, 7),
(24, 6, 34),
(24, 4, 55),
(24, 9, 33),
(24, 8, 16),
(24, 10, 64),
(24, 11, 2635),
(25, 7, 388),
(25, 1, 58),
(25, 12, 80),
(25, 2, 7),
(25, 3, 89),
(25, 5, 17),
(25, 6, 55),
(25, 4, 105),
(25, 9, 63),
(25, 8, 30),
(25, 10, 93),
(25, 11, 2142),
(26, 7, 304),
(26, 1, 32),
(26, 12, 55),
(26, 2, 14),
(26, 3, 79),
(26, 5, 5),
(26, 6, 35),
(26, 4, 64),
(26, 9, 44),
(26, 8, 25),
(26, 10, 54),
(26, 11, 2446),
(30, 7, 815),
(30, 1, 180),
(30, 12, 205),
(30, 2, 86),
(30, 3, 400),
(30, 5, 200),
(30, 6, 361),
(30, 4, 295),
(30, 9, 355),
(30, 8, 118),
(30, 10, 595),
(30, 11, 5465),
(28, 7, 721),
(28, 1, 129),
(28, 12, 152),
(28, 2, 73),
(28, 3, 386),
(28, 5, 112),
(28, 6, 471),
(28, 4, 318),
(28, 9, 368),
(28, 8, 191),
(28, 10, 545),
(28, 11, 5211),
(29, 7, 665),
(29, 1, 168),
(29, 12, 127),
(29, 2, 111),
(29, 3, 567),
(29, 5, 139),
(29, 6, 540),
(29, 4, 391),
(29, 9, 345),
(29, 8, 251),
(29, 10, 897),
(29, 11, 7631),
(31, 7, 505),
(31, 1, 79),
(31, 12, 79),
(31, 2, 142),
(31, 3, 199),
(31, 5, 47),
(31, 6, 146),
(31, 4, 180),
(31, 9, 103),
(31, 8, 172),
(31, 10, 348),
(31, 11, 3874),
(35, 7, 1093),
(35, 1, 197),
(35, 12, 237),
(35, 2, 64),
(35, 3, 486),
(35, 5, 79),
(35, 6, 473),
(35, 4, 367),
(35, 9, 438),
(35, 8, 328),
(35, 10, 447),
(35, 11, 8465),
(32, 7, 236),
(32, 1, 33),
(32, 12, 55),
(32, 2, 27),
(32, 3, 107),
(32, 5, 7),
(32, 6, 38),
(32, 4, 99),
(32, 9, 66),
(32, 8, 40),
(32, 10, 228),
(32, 11, 2400),
(33, 7, 203),
(33, 1, 57),
(33, 12, 82),
(33, 2, 17),
(33, 3, 145),
(33, 5, 5),
(33, 6, 50),
(33, 4, 83),
(33, 9, 37),
(33, 8, 43),
(33, 10, 128),
(33, 11, 2259),
(34, 7, 447),
(34, 1, 110),
(34, 12, 179),
(34, 2, 16),
(34, 3, 84),
(34, 5, 13),
(34, 6, 91),
(34, 4, 68),
(34, 9, 53),
(34, 8, 39),
(34, 10, 127),
(34, 11, 3610);

-- --------------------------------------------------------

--
-- Table structure for table `crime`
--

CREATE TABLE `crime` (
  `ID` int(4) NOT NULL,
  `Name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `crime`
--

INSERT INTO `crime` (`ID`, `Name`) VALUES
(1, 'Murder'),
(2, 'Rape'),
(3, 'Kidnapping/Abduction'),
(4, 'Burglary'),
(5, 'Dacoity'),
(6, 'Robbery '),
(7, 'Assault'),
(8, 'Cattle Theft'),
(9, 'Vehicle theft'),
(10, 'Other Theft'),
(11, 'Other'),
(12, 'Attempted Murder');

-- --------------------------------------------------------

--
-- Table structure for table `district`
--

CREATE TABLE `district` (
  `ID` int(4) NOT NULL,
  `Name` text NOT NULL,
  `Population` mediumint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `district`
--

INSERT INTO `district` (`ID`, `Name`, `Population`) VALUES
(1, 'Bhawalnagar', 280100),
(2, 'Bhawalpur', 3582000),
(3, 'Rahim Yar Khan', 4692000),
(4, 'Dera Ghazi Khan', 2487000),
(5, 'Layyah', 1656000),
(6, 'Muzaffargarh', 4021000),
(7, 'Rajanpur', 1664000),
(8, 'Chiniot', 1246000),
(9, 'Faislabad', 7469000),
(10, 'Jhang', 2486000),
(11, 'Toba Taik Singh', 2130000),
(12, 'Gujranwala', 4869000),
(13, 'Hafizabad', 1113000),
(14, 'Mandi Baha Ud Din', 1479000),
(15, 'Narowal', 1631000),
(16, 'Sialkot', 3728000),
(17, 'Lahore', 8388607),
(18, 'Nankana Sahib', 1318000),
(19, 'Sheikupura', 3172000),
(20, 'Khanewal', 2826000),
(21, 'Lodhran', 1658000),
(22, 'Multan', 4403000),
(23, 'Vehari', 2942000),
(24, 'Attock', 1697000),
(25, 'Chakwal', 1400000),
(26, 'Jhelum', 1226000),
(27, 'Rawalpindi', 4769000),
(28, 'Arifwala', 2430000),
(29, 'Okara', 3039000),
(30, 'Sahiwal', 2430000),
(31, 'Pakpattan', 1770000),
(32, 'Bhakkar', 1483000),
(33, 'Khushab', 1179000),
(34, 'Mianwali', 1427000),
(35, 'Sargodha', 3437000);

-- --------------------------------------------------------

--
-- Table structure for table `division`
--

CREATE TABLE `division` (
  `Code` int(4) NOT NULL,
  `Name` text NOT NULL,
  `Population` mediumint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `division`
--

INSERT INTO `division` (`Code`, `Name`, `Population`) VALUES
(1, 'Bhawalpur', 3582000),
(2, 'Dera Ghazi Khan', 2487000),
(3, 'Faisalabad', 7469000),
(4, 'Gujranwala', 4869000),
(5, 'Lahore', 8388607),
(6, 'Multan', 4403000),
(7, 'Rawalpindi', 4769000),
(8, 'Sahiwal', 2430000),
(9, 'Sargodha', 1483000);

-- --------------------------------------------------------

--
-- Table structure for table `form`
--

CREATE TABLE `form` (
  `FIR` int(4) NOT NULL,
  `District_ID` int(4) NOT NULL,
  `Crime_ID` int(4) NOT NULL,
  `c_location` text NOT NULL,
  `date_time` datetime NOT NULL DEFAULT current_timestamp(),
  `death` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `reporter`
--

CREATE TABLE `reporter` (
  `CNIC` bigint(13) NOT NULL,
  `Name` varchar(25) NOT NULL,
  `Phone` varchar(14) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reporter`
--

INSERT INTO `reporter` (`CNIC`, `Name`, `Phone`) VALUES
(3520189680229, 'Muhammad Ozair Attiq', '0123-4567-789');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `first name` text NOT NULL,
  `last name` text NOT NULL,
  `phone` varchar(13) NOT NULL,
  `password` varchar(8) NOT NULL,
  `employee-id` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`first name`, `last name`, `phone`, `password`, `employee-id`) VALUES
('Ozair', 'Attiq', '0123-4567-789', 'ozair123', '12312');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `code to id`
--
ALTER TABLE `code to id`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Code` (`Code`);

--
-- Indexes for table `counter`
--
ALTER TABLE `counter`
  ADD KEY `district_id` (`district_id`),
  ADD KEY `crime_id` (`crime_id`);

--
-- Indexes for table `crime`
--
ALTER TABLE `crime`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `district`
--
ALTER TABLE `district`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `division`
--
ALTER TABLE `division`
  ADD PRIMARY KEY (`Code`);

--
-- Indexes for table `form`
--
ALTER TABLE `form`
  ADD PRIMARY KEY (`FIR`),
  ADD KEY `District_ID` (`District_ID`),
  ADD KEY `Crime_ID` (`Crime_ID`);

--
-- Indexes for table `reporter`
--
ALTER TABLE `reporter`
  ADD PRIMARY KEY (`CNIC`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`employee-id`),
  ADD KEY `password` (`password`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `crime`
--
ALTER TABLE `crime`
  MODIFY `ID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `district`
--
ALTER TABLE `district`
  MODIFY `ID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `division`
--
ALTER TABLE `division`
  MODIFY `Code` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `form`
--
ALTER TABLE `form`
  MODIFY `FIR` int(4) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `code to id`
--
ALTER TABLE `code to id`
  ADD CONSTRAINT `code to id_ibfk_1` FOREIGN KEY (`id`) REFERENCES `district` (`ID`),
  ADD CONSTRAINT `code to id_ibfk_2` FOREIGN KEY (`Code`) REFERENCES `division` (`Code`);

--
-- Constraints for table `counter`
--
ALTER TABLE `counter`
  ADD CONSTRAINT `counter_ibfk_1` FOREIGN KEY (`district_id`) REFERENCES `district` (`ID`),
  ADD CONSTRAINT `counter_ibfk_2` FOREIGN KEY (`crime_id`) REFERENCES `crime` (`ID`);

--
-- Constraints for table `form`
--
ALTER TABLE `form`
  ADD CONSTRAINT `form_ibfk_2` FOREIGN KEY (`Crime_ID`) REFERENCES `counter` (`crime_id`),
  ADD CONSTRAINT `form_ibfk_3` FOREIGN KEY (`District_ID`) REFERENCES `code to id` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
